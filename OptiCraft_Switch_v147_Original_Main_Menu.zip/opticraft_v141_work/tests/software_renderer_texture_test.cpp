#include "software_renderer.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
using namespace opti::gl;

int main() {
    TextureStore textures;
    assert(textures.create(7));
    const std::uint8_t texels[] = {
        255,0,0,255, 0,255,0,255,
        0,0,255,255, 255,255,255,255
    };
    assert(textures.upload(7,2,2,PixelFormat::RGBA,texels,sizeof(texels),1));
    assert(textures.set_filter(7,true,TextureFilter::Nearest));
    assert(textures.set_filter(7,false,TextureFilter::Nearest));
    assert(textures.set_wrap(7,true,TextureWrap::Clamp));
    assert(textures.set_wrap(7,false,TextureWrap::Clamp));

    DrawBatch batch;
    batch.indices={0,1,2};
    Vertex a,b,c;
    a.clip_position={-1,-1,0,1}; a.texcoord={0,0,0,1};
    b.clip_position={ 1,-1,0,1}; b.texcoord={1,0,0,1};
    c.clip_position={-1, 1,0,1}; c.texcoord={0,1,0,1};
    a.color=b.color=c.color={1,1,1,1};
    batch.vertices={a,b,c};

    RenderState state;
    state.viewport={0,0,8,8};
    state.texture_2d=true;
    SoftwareRenderer renderer(8,8);
    renderer.clear(state);
    renderer.draw(batch,state,textures,7);

    // The triangle covers the lower-left half; sample interior pixels near each corner.
    const auto& pixels=renderer.color_buffer();
    const auto blue=pixels[1*8+1];
    const auto green=pixels[6*8+6];
    const auto red=pixels[6*8+1];
    assert(((blue>>16)&255u)>200u && (blue&255u)<30u);
    assert(((green>>8)&255u)>150u && (green&255u)<30u);
    assert((red&255u)>150u && ((red>>8)&255u)<30u);

    // Legacy untextured overload remains available and does not sample a texture.
    state.texture_2d=false;
    renderer.clear(state);
    renderer.draw(batch,state);
    assert(renderer.color_buffer()[1*8+1]==0xFFFFFFFFu);
    std::cout<<"software_renderer_texture_test: PASS\\n";
}
