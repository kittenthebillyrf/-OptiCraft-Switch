#pragma once
#include "class_code_parser.hpp"
#include "jvm_runtime.hpp"
#include "jvm_execution_frames.hpp"
#include <cstddef>
#include <string>
#include <vector>
namespace opti::runtime {
class JvmClassRuntime;
}
namespace opti::gl { class LwjglGL11Bridge; }
namespace opti::runtime {
struct AwtHostCallbacks {
    void* user = nullptr;
    bool (*create_window)(void*, const char*, int, int) = nullptr;
    bool (*set_visible)(void*, bool) = nullptr;
};

struct ObjectExecutionResult {
    bool success = false;
    JvmValue value = NullValue{};
    std::string error;
    std::size_t instructions_executed = 0;
};

// Interpreter for the executable subset implemented by this project.
// When a class runtime is supplied, method calls and object layouts are resolved
// across registered classes instead of being limited to the current class.
class ObjectBytecodeInterpreter {
public:
    explicit ObjectBytecodeInterpreter(JvmHeap& heap, JvmStaticFields& statics,
                                       std::size_t budget = 1000000,
                                       JvmClassRuntime* classes = nullptr,
                                       AwtHostCallbacks* awt_host = nullptr,
                                       opti::gl::LwjglGL11Bridge* gl_bridge = nullptr)
        : heap_(heap), statics_(statics), budget_(budget), classes_(classes), awt_host_(awt_host), gl_bridge_(gl_bridge) {}

    const JvmExecutionFrameStack& execution_frames() const { return execution_frames_; }
    const std::string& diagnostics() const { return diagnostics_; }

    ObjectExecutionResult invoke_static(const ParsedClassCode& cls,
                                        const std::string& name,
                                        const std::string& descriptor,
                                        const std::vector<JvmValue>& args);

private:
    JvmHeap& heap_;
    JvmStaticFields& statics_;
    std::size_t budget_;
    JvmClassRuntime* classes_;
    AwtHostCallbacks* awt_host_;
    opti::gl::LwjglGL11Bridge* gl_bridge_;
    ObjectRef current_thread_ = 0;
    JvmExecutionFrameStack execution_frames_;
    std::string diagnostics_;
};
}
