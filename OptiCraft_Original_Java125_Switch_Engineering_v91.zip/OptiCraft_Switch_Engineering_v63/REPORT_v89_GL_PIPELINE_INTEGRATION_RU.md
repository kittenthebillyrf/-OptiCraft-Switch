# OptiCraft Switch — инженерный этап v89

## Цель этапа
Свести отдельные GL-адаптеры в общий CPU-side графический контекст и сделать путь вывода его RGBA8 framebuffer в линейный framebuffer libnx.

## Большие изменения

### 1. Fixed-function fragment state
В `RenderState` добавлены параметры alpha test:
- compare functions: NEVER, LESS, EQUAL, LEQUAL, GREATER, NOTEQUAL, GEQUAL, ALWAYS;
- reference value с clamp в диапазон [0,1].

Добавлены факторы blending:
- ZERO, ONE;
- SRC_COLOR / ONE_MINUS_SRC_COLOR;
- DST_COLOR / ONE_MINUS_DST_COLOR;
- SRC_ALPHA / ONE_MINUS_SRC_ALPHA;
- DST_ALPHA / ONE_MINUS_DST_ALPHA.

SoftwareRenderer теперь:
- применяет выбранную depth comparison function;
- выполняет alpha test после текстурирования, то есть по результирующей alpha;
- выполняет RGBA blending с выбранными source/destination factors;
- записывает depth только после прошедших тестов.

Также добавлены базовые запросы состояния: `is_enabled`, `get_integer` (viewport, depth func, blend factors, alpha func), `get_float` (alpha reference). Некорректные enum для alpha/depth/blend теперь отклоняются.

### 2. Client array расширения
- Добавлен `interleaved_arrays` для основных legacy layouts OpenGL: V2F, V3F, C4UB_V2F/V3F, C3F_V3F, N3F_V3F, C4F_N3F_V3F, T2F_V3F, T4F_V4F и основные T2F-комбинации.
- Добавлен `array_element` для получения атрибутов отдельной вершины из включённых массивов.
- Исправлена числовая семантика: integer vertex/texcoord/normal массивы читаются как числовые значения; integer color arrays нормализуются в диапазон цвета, signed minimum ограничивается -1.
- Расширены тесты interleaved layouts, array element, signed/unsigned color conversion и integer positions.

### 3. Единый CPU-side GL context
Новый `LegacyGLContext` связывает:
- `CompatCore`;
- `ClientArrays`;
- `TextureApi` и `TextureStore`;
- `SoftwareRenderer`.

Immediate-mode `begin/end`, `draw_arrays` и `draw_elements` теперь проходят через один submit path в общий framebuffer. Это внутренний совместимый контекст, а не готовая реализация OpenGL 1.1 ABI/JNI.

### 4. Switch framebuffer output bridge
- Добавлен независимый тестируемый `blit_rgba8`, который копирует CPU RGBA8 buffer в destination с произвольным row stride.
- Добавлен `platform_present_rgba8` для linear framebuffer, созданного через libnx `Framebuffer` с `PIXEL_FORMAT_RGBA_8888`.
- Прямой вызов helper протестирован на host; `switch_diagnostic_main.cpp` прошёл syntax-check на mock libnx API.

## Проверки
В `VALIDATION_v89.txt` записаны все результаты. Полный suite содержит 13 проверок:
- GL state/matrices/primitives;
- texture API/store/textured rasterizer;
- client arrays;
- alpha/depth/blending;
- unified legacy context;
- RGBA framebuffer blit;
- input implementation/JNI;
- platform source syntax;
- Sys JNI ABI;
- original LWJGL BufferUtils JNI ABI.

## Что ещё не сделано
- JNI entry points для полного набора OpenGL функций оригинального LWJGL 2.9.4.
- Полная реализация OpenGL 1.1: display lists, VBO-independent client attrib stacks, lighting/fog/clip behavior, line/point rasterization, texture environment modes, mipmaps и ещё множество state queries.
- Аппаратный GPU backend Switch (текущая графика CPU-only).
- Интеграция JVM/HotSpot с Horizon OS и подключение original minecraft.jar к реальному runtime.
- Java Sound / Switch audio, filesystem bridge и полноценный game loop.
- Сборка NRO с новым графическим контекстом и проверка на самой консоли.

## Честная оценка готовности
Оценка инженерной готовности всего порта после этого блока: **примерно 18–20%**. Это экспертная оценка распределения работ, а не замер готовности билда. Графическая основа стала связанной, но самый крупный критический блок — Java Runtime на Switch — всё ещё не интегрирован. NRO и запуск Minecraft не подтверждены.

## Сверка API
Семантика fragment blending и legacy OpenGL API сверялась с OpenGL specifications и registry Khronos. Хостовые тесты не заменяют тестирование на Horizon OS.
