OptiCraft Java Lite 1.2.5 → Nintendo Switch
Этап v67–v70: проверяемый JNI input bridge.

Проверки на хосте:
  bash tests/run_sys_native_test.sh
  bash tests/run_input_jni_test.sh

Требуются JDK и g++.
Сборка NRO и запуск на Nintendo Switch не выполнялись.
