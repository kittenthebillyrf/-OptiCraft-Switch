# OptiCraft Switch — v91: первый NRO-кандидат

## Цель этапа
Подготовить минимальную точку входа приложения, которую можно отдельно собрать как `.nro`, не затягивая в неё незавершённую JVM/JNI/рендер-подсистему.

## Что добавлено
- `switch_nro/main.cpp` — небольшой libnx homebrew entry point.
- Экран первого запуска OptiCraft с честным отображением статусов.
- Опрос стандартного контроллера Switch: A фиксирует событие, Plus завершает приложение.
- `assets/opticraft_icon.jpg` — встроенная иконка NRO.
- `Makefile` переключён на изолированную цель `OptiCraft.nro`; старые Java/JNI/C++ модули больше не компилируются случайно в диагностический NRO.
- `tools/preflight_switch_nro.sh` проверяет наличие devkitPro/libnx/elf2nro/nacptool.
- Обновлены Linux/MSYS2 и Windows PowerShell build-скрипты.
- `tests/run_first_nro_syntax_test.sh` выполняет host syntax-check против mock libnx API.
- `docs/HOME_MENU_FORWARDER_RU.md` фиксирует архитектуру плитки HOME Menu.

## Как будет выглядеть первый запуск
Экран показывает, что NRO стартовал, libnx event loop активен и контроллер опрашивается. Статусы `JAVA RUNTIME`, `MINECRAFT.JAR` и `LWJGL JNI` намеренно помечены как не подключённые, чтобы диагностический экран нельзя было принять за запущенный Minecraft.

## Сборка
Из devkitPro MSYS2 shell:
```bash
export DEVKITPRO=/opt/devkitpro   # заменить на фактический путь установки
./build_switch.sh
```
На Windows PowerShell из среды devkitPro:
```powershell
$env:DEVKITPRO = "C:\devkitPro"
.\build_windows.ps1
```
Ожидаемый файл: `OptiCraft.nro`.
Расположение для SD: `switch/OptiCraft/OptiCraft.nro`.

## Ярлык HOME Menu
Сам NRO не может штатно создать себе системную плитку. Для этого предусмотрен отдельный forwarder NSP, который указывает на фиксированный NRO path. Он намеренно не включён в v91; сначала нужен реальный запуск NRO на Switch. См. `docs/HOME_MENU_FORWARDER_RU.md`.

## Проверки и ограничения
- Host C++ syntax-check проверяет только синтаксис entry point относительно mock libnx API.
- В среде разработки отсутствуют devkitA64, libnx install tree, `elf2nro` и `nacptool`; поэтому `OptiCraft.nro` здесь не собран.
- Консольный запуск не выполнен.
- JVM, Minecraft JAR execution и полноценный Minecraft boot не входят в этот этап.
