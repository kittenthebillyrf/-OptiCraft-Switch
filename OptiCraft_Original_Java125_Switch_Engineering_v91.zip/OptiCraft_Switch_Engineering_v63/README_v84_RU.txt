OptiCraft Original Java 1.2.5 -> Nintendo Switch
Engineering snapshot v84

This package extends the v80 engineering workspace with:
- exact GL11 JNI ABI mapping for the original bundled LWJGL 2.9.4;
- a standalone RGBA texture store with basic OpenGL pixel formats, nearest/bilinear sampling, and wrap modes;
- a strict host-side test for the texture store.

Start with:
- REPORT_v81_v84_TEXTURES_JNI_RU.md
- abi/ORIGINAL_MINECRAFT_GL11_JNI_ABI_v81.csv
- tests/run_texture_store_test.sh

IMPORTANT:
This is source-level engineering work, not a runnable Switch port.
No NRO was built and no Switch runtime test was performed.
The texture store is not yet connected to GL11 JNI calls or the software rasterizer.
