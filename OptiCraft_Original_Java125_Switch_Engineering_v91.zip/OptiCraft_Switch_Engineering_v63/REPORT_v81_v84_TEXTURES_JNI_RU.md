# OptiCraft Switch — большой инженерный блок v81–v84

## Что добавлено

### 1. Реестр точного OpenGL JNI ABI оригинального LWJGL 2.9.4
- Извлечены сигнатуры из `org.lwjgl.opengl.GL11` именно из `lwjgl.jar`, который находится в пользовательском архиве OptiCraft.
- Сопоставлены 69 методов GL11, вызываемых классами оригинального Minecraft, с низкоуровневыми `ngl*` native entrypoints.
- Для 63 из 69 вызовов найден прямой native entrypoint и записан точный JVM descriptor.
- Для оставшихся методов отмечено, что это Java wrapper/непрямой native путь; их нельзя регистрировать как JNI-функции по догадке.
- Полная таблица: `abi/ORIGINAL_MINECRAFT_GL11_JNI_ABI_v81.csv`.

Это важный шаг: JNI должен соответствовать не абстрактному LWJGL или современному Minecraft, а конкретному бинарному LWJGL 2.9.4 из комплекта OptiCraft.

### 2. Начальная система текстур
Добавлены `include/texture_store.hpp` и `src/texture_store.cpp`:
- создание и удаление текстур по ID;
- загрузка пикселей в RGBA из Alpha, Luminance, LuminanceAlpha, RGB и RGBA;
- проверка размеров, переполнения и длины входного буфера;
- параметры фильтрации Nearest/Linear;
- режимы адресации Repeat/Clamp;
- выборка ближайшего texel и билинейная фильтрация;
- безопасное поведение для отсутствующей/неполной текстуры.

### 3. Автотесты
`tests/run_texture_store_test.sh` компилирует тест с `-Wall -Wextra -Werror` и проверяет:
- загрузку RGB и LuminanceAlpha;
- корректность каналов RGBA;
- выборку texel;
- параметры фильтрации и wrap;
- удаление текстуры;
- отказ при некорректном размере входных данных.

## Проверки
- `texture_store_test`: PASS (host g++).
- JNI ABI: сопоставление построено по `javap -private -s` из оригинального `lwjgl.jar`.
- Это не тест на Nintendo Switch и не подтверждение полноценного GL/OpenGL runtime.

## Что ещё не сделано
- TextureStore пока является отдельным проверенным модулем: он ещё не подключён к `glTexImage2D`/`glTexSubImage2D` JNI entrypoints и не участвует в rasterizer sampling.
- Не реализованы все GL11 native entrypoints Minecraft, display lists, client arrays и весь fixed-function pipeline.
- Нет готовой интеграции JVM + LWJGL + libnx на Horizon OS.
- NRO не собран, на Switch запуск не проверялся.

## Следующий большой этап
Связать GL11 native entrypoints с состоянием CompatCore и TextureStore: `glGenTextures`, `glBindTexture`, `glTexImage2D`, `glTexSubImage2D`, `glTexParameteri`, `glDeleteTextures`; затем подключить текстурную выборку к треугольному рендереру.
