# Отчёт v61–v63

- Сверены JNI-дескрипторы `org.lwjgl.DefaultSysImplementation` по оригинальному LWJGL 2.9.4.
- Реализованы `getJNIVersion()I`, `getPointerSize()I`, `setDebug(Z)V`.
- Новые методы зарегистрированы вместе с двумя проверенными методами `BufferUtils`.
- Добавлен тест на оригинальном `lwjgl.jar`: Java загружает host shared library и вызывает методы через JNI.

Проверка: `bash tests/run_sys_native_test.sh` (JDK + g++).

Это host ABI smoke-test. NRO не собирался, теста на Switch не было.
Остаются native loader для Horizon, Display/OpenGL backend, Keyboard/Mouse,
AWT, Java Sound и интеграция JVM.
