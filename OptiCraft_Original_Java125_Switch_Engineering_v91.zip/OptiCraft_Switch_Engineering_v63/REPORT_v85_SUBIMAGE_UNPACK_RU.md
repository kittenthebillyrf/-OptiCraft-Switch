# OptiCraft Switch — блок v85: GL texture upload semantics

## Что изменено
- `TextureStore::upload` теперь учитывает `GL_UNPACK_ALIGNMENT` (1/2/4/8), включая padding между строками.
- Добавлен `TextureStore::sub_upload` для обновления прямоугольной области уже созданной текстуры без перераспределения всего изображения.
- Конвертация Alpha, Luminance, LuminanceAlpha, RGB и RGBA выполняется общим проверяемым путём.
- Добавлены проверки размеров, границ подпрямоугольника, размера входного буфера и переполнения арифметики до изменения текстуры.
- При ошибке существующая текстура остаётся неизменной.

## Проверка
- `tests/run_texture_store_test.sh` — PASS (host g++, C++17, -Wall -Wextra -Werror).
- Тест проверяет RGB/RGBA-представление, LuminanceAlpha, фильтрацию, обновление texel через sub-upload, GL-выравнивание RGB-строк и отказ при выходе за границы.

## Важные ограничения
Это хранилище текстур и CPU-side upload semantics. Оно ещё не подключено к JNI `glTexImage2D` / `glTexSubImage2D`, не является полным OpenGL и не доказывает работу на Nintendo Switch. Нативная сборка Horizon/NRO и запуск оригинального Minecraft не выполнялись.
