#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
"$ROOT/tools/preflight_switch_nro.sh"
export PATH="$DEVKITPRO/devkitA64/bin:$DEVKITPRO/tools/bin:$PATH"
make clean
make all
test -s "$ROOT/OptiCraft.nro"
mkdir -p "$ROOT/dist/switch/OptiCraft"
cp "$ROOT/OptiCraft.nro" "$ROOT/dist/switch/OptiCraft/OptiCraft.nro"
cp "$ROOT/assets/opticraft_icon.jpg" "$ROOT/dist/switch/OptiCraft/opticraft_icon.jpg"
echo "Built: $ROOT/OptiCraft.nro"
echo "SD target: /switch/OptiCraft/OptiCraft.nro"
