# OptiCraft Switch — этап v71–v74: Java InputImplementation

## Реальное изменение
Добавлен `org.lwjgl.switchport.SwitchInputImplementation`, который реализует
оригинальный интерфейс `org.lwjgl.opengl.InputImplementation` из LWJGL 2.9.4.

Подключено:
- `pollKeyboard`: заполняет LWJGL key-state ByteBuffer.
- `readKeyboard`: сериализует события в формат, который читает Keyboard.next().
- `pollMouse`: заполняет координаты, колесо и button-state ByteBuffer.
- `readMouse`: сериализует события в формат Mouse.next().
- `pump`: принимает состояние контроллера от платформенного цикла и подаёт
  события в JNI bridge.
- Реализованы базовые lifecycle методы клавиатуры/мыши; аппаратные курсоры
  честно обозначены неподдерживаемыми.

## Тестирование
На host JVM с оригинальным LWJGL 2.9.4:
- Java-класс успешно компилируется против оригинального InputImplementation.
- W key state читается через `pollKeyboard`.
- keyboard event проходит через `readKeyboard` в LWJGL-формате.
- left mouse button state читается через `pollMouse`.
- mouse event проходит через `readMouse` в LWJGL-формате.

Тесты не запускают Minecraft и не доказывают работу на Horizon OS.

## Оставшиеся ограничения
- `pump()` пока не вызывается реальным libnx Npad loop на Switch.
- Нужно проверить/уточнить маппинг физических кнопок по реальному HID.
- Нет интеграции с `Display.getImplementation()`/инициализацией LWJGL.
- Display/OpenGL backend не реализован.
- Не собран NRO, нет ARM64/Horizon теста.
