OptiCraft Java 1.2.5 + OptiFine HD U C7 → Nintendo Switch
Инженерный пакет v90

Новое:
- ZIP/JAR central directory inspector;
- проверка наличия Minecraft main class;
- Java launch plan и classpath;
- тестируемый VM bootstrap callback contract;
- Java 6 bytecode adapter build script;
- аудит исходных minecraft/lwjgl/jinput JAR.

См.:
- REPORT_v90_JAVA_BOOTSTRAP_RU.md
- ORIGINAL_PACKAGE_AUDIT_v90.txt
- VALIDATION_v90.txt

ВАЖНО:
JVM для Horizon OS ещё не интегрирована. Bootstrap использует тестовые callbacks и не запускает Java. switchport.jar в этом окружении не собран. NRO и запуск Minecraft на Switch не подтверждены.
