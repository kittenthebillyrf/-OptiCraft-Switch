# LWJGL 2.9.4 input event ABI (verified from bundled bytecode)

The bundled `org.lwjgl.input.Keyboard.next()` consumes each keyboard event in this order:
1. `int` key code
2. `byte` pressed state
3. `int` character code
4. `long` timestamp in nanoseconds
5. `byte` repeat flag

Total: 18 bytes per keyboard event (Java ByteBuffer byte order must be set to native order).

The bundled `org.lwjgl.input.Mouse.next()` consumes each mouse event in this order:
1. `byte` button index
2. `byte` pressed state
3. `int` X or relative delta X (depending on grab mode)
4. `int` Y or relative delta Y
5. `int` wheel delta
6. `long` timestamp in nanoseconds

Total: 22 bytes per mouse event.

The new JNI bridge emits normalized event tuples `(type, code, x, y)` and maintains
key/button state. A future `InputImplementation` must serialize these tuples into
the exact LWJGL byte layouts above, populate poll-state buffers, and use monotonic
nanosecond timestamps. That final Java adapter is not yet implemented.
