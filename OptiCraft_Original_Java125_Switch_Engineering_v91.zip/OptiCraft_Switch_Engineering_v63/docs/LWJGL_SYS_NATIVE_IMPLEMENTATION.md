# LWJGL 2.9.4 Sys JNI bridge

Implemented exact `org.lwjgl.DefaultSysImplementation` native methods:
- `getJNIVersion()I` — returns LWJGL native ABI level 19.
- `getPointerSize()I` — returns target `sizeof(void*)`.
- `setDebug(Z)V` — stores the debug flag.

The existing `BufferUtils.zeroBuffer0` and `BufferUtils.getBufferAddress`
JNI registrations are retained in the same library.

Limitations: this does not implement the complete Sys platform layer, native
library extraction/loading, AWT, clipboard, URL launching, Display/OpenGL,
Keyboard/Mouse, audio, or game startup. Host tests do not prove ARM64/Horizon
compatibility and do not constitute a Switch build.
