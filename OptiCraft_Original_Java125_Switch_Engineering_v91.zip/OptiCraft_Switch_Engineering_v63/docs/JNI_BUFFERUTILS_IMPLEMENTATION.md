# JNI bridge status

## Implemented and tested against original bundled LWJGL

Class: `org.lwjgl.BufferUtils`

| Native method | JVM descriptor | Status |
|---|---|---|
| `zeroBuffer0` | `(Ljava/nio/Buffer;JJ)V` | Implemented |
| `getBufferAddress` | `(Ljava/nio/Buffer;)J` | Implemented |

Implementation: `src/lwjgl_bufferutils_jni.cpp`.

The bridge uses `JNI_OnLoad` + `RegisterNatives`, `GetDirectBufferAddress`, and `GetDirectBufferCapacity`. It handles direct ByteBuffer and typed NIO buffers, converts element capacity to byte capacity, checks offset/length, and zeros the requested byte range.

## Verified host integration

The test was compiled as a shared JNI library and loaded by Java. It used the exact `lwjgl.jar` extracted from the original OptiCraft archive, not a mock class.

Verified:
- Original `BufferUtils.zeroBuffer(ByteBuffer)` dispatches into native `zeroBuffer0`.
- Original `BufferUtils.zeroBuffer(IntBuffer)` dispatches into native `zeroBuffer0`.
- Original package-private `getBufferAddress(Buffer)` returns a non-null address.
- Buffer position/limit range is respected.

## Not implemented

This is only the BufferUtils native slice. It does not implement:
- `Sys` / native library loading on Horizon;
- Display/window/context creation;
- GL11/GL13/ARB OpenGL native methods;
- OpenAL;
- JNI library loading inside the selected Switch JVM;
- the complete native surface of LWJGL.

Do not replace the original LWJGL JAR with this source. This code is intended to become part of the Switch native bridge once the JVM's native library loader and target build are integrated.
