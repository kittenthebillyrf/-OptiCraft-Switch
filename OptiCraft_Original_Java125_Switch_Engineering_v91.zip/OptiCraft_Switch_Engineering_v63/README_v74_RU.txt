OptiCraft Java Lite 1.2.5 → Nintendo Switch
Этап v71–v74: Java InputImplementation.

Тесты:
  bash tests/run_sys_native_test.sh
  bash tests/run_input_jni_test.sh
  bash tests/run_input_implementation_test.sh

Для теста InputImplementation нужен оригинальный LWJGL 2.9.4 JAR:
  tests/extracted/lwjgl.jar

Host PASS не равен Switch PASS. NRO и игровой запуск ещё не выполнены.
