#include "input_adapter.hpp"

namespace opti {
namespace {
constexpr std::uint64_t B_A=1ull<<0, B_B=1ull<<1, B_X=1ull<<2, B_Y=1ull<<3;
constexpr std::uint64_t B_L=1ull<<6, B_R=1ull<<7;
constexpr std::uint64_t B_LEFT=1ull<<12, B_UP=1ull<<13, B_RIGHT=1ull<<14, B_DOWN=1ull<<15;
constexpr std::int32_t DEADZONE=10000;
enum KeySlot { W, S, A, D, ESC, E, Q, UP, DOWN, LEFT, RIGHT, KEY_COUNT };
constexpr int KEY_CODES[KEY_COUNT] = {KEY_W,KEY_S,KEY_A,KEY_D,KEY_ESCAPE,KEY_E,KEY_Q,KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT};
void append(EventBatch& batch, InputEvent::Type type, int code) {
    if (batch.count < 16) batch.events[batch.count++] = {type, code};
}
}
EventBatch InputAdapter::update(const ControllerFrame& f) {
    std::uint32_t keys=0, mouse=0;
    if (f.left_y > DEADZONE) keys |= 1u<<W;
    if (f.left_y < -DEADZONE) keys |= 1u<<S;
    if (f.left_x < -DEADZONE) keys |= 1u<<A;
    if (f.left_x > DEADZONE) keys |= 1u<<D;
    if (f.buttons & B_B) keys |= 1u<<ESC;
    if (f.buttons & B_X) keys |= 1u<<E;
    if (f.buttons & B_Y) keys |= 1u<<Q;
    if (f.buttons & B_UP) keys |= 1u<<UP;
    if (f.buttons & B_DOWN) keys |= 1u<<DOWN;
    if (f.buttons & B_LEFT) keys |= 1u<<LEFT;
    if (f.buttons & B_RIGHT) keys |= 1u<<RIGHT;

    // L=place (right mouse), R=break (left mouse), A=select (left mouse).
    if (f.buttons & (B_A|B_R)) mouse |= 1u;
    if (f.buttons & B_L) mouse |= 1u<<1;

    EventBatch batch{};
    for (int slot=0; slot<KEY_COUNT; ++slot) {
        const std::uint32_t mask=1u<<slot;
        if ((keys&mask) && !(previous_keys_&mask)) append(batch,InputEvent::KeyDown,KEY_CODES[slot]);
        if (!(keys&mask) && (previous_keys_&mask)) append(batch,InputEvent::KeyUp,KEY_CODES[slot]);
    }
    for (int b=0; b<2; ++b) {
        const std::uint32_t mask=1u<<b;
        if ((mouse&mask) && !(previous_mouse_&mask)) append(batch,InputEvent::MouseDown,b);
        if (!(mouse&mask) && (previous_mouse_&mask)) append(batch,InputEvent::MouseUp,b);
    }
    previous_keys_=keys;
    previous_mouse_=mouse;
    return batch;
}
void InputAdapter::reset() { previous_keys_=0; previous_mouse_=0; }
}
