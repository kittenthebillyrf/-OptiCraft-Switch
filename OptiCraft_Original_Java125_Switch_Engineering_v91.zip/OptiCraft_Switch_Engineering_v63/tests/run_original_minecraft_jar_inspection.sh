#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/opti_inspect_minecraft_jar"
TMP="${TMPDIR:-/tmp}/opti_original_minecraft_jar"
"${CXX:-g++}" -std=c++17 -Wall -Wextra -Werror -I"$ROOT/include" "$ROOT/src/java_runtime_bootstrap.cpp" "$ROOT/tools/inspect_minecraft_jar.cpp" -o "$OUT"
python3 - "$TMP" <<'PY'
import sys,zipfile
outer="/mnt/data/OptiCraft JAVA LITE 1.2.5.zip"
with zipfile.ZipFile(outer) as z:
    name=next(n for n in z.namelist() if n.endswith("/mcdata/bin/minecraft.jar"))
    open(sys.argv[1],"wb").write(z.read(name))
PY
"$OUT" "$TMP"
