#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
g++ -std=c++17 -Wall -Wextra -I"$ROOT/tests/fake_switch" -I"$ROOT/include" \
  -fsyntax-only "$ROOT/src/switch_diagnostic_main.cpp"
echo "PASS: libnx platform source syntax against mock API"
