#include "input_adapter.hpp"
#include <cassert>

int main() {
    opti::InputAdapter adapter;
    opti::ControllerFrame f{};
    auto first = adapter.update(f);
    assert(first.count == 0);

    // Move left stick forward: exactly one W key-down transition.
    f.left_y = 20000;
    auto down = adapter.update(f);
    assert(down.count == 1);
    assert(down.events[0].type == opti::InputEvent::KeyDown);
    assert(down.events[0].code == opti::KEY_W);

    // Held key must not emit another key-down.
    auto held = adapter.update(f);
    assert(held.count == 0);

    // Release must emit one key-up.
    f.left_y = 0;
    auto up = adapter.update(f);
    assert(up.count == 1);
    assert(up.events[0].type == opti::InputEvent::KeyUp);
    assert(up.events[0].code == opti::KEY_W);

    // L places (right mouse button), R breaks (left mouse button).
    f.buttons = (1ull << 6) | (1ull << 7);
    auto clicks = adapter.update(f);
    assert(clicks.count == 2);
    assert(clicks.events[0].type == opti::InputEvent::MouseDown);
    assert(clicks.events[0].code == opti::MOUSE_LEFT);
    assert(clicks.events[1].type == opti::InputEvent::MouseDown);
    assert(clicks.events[1].code == opti::MOUSE_RIGHT);
    return 0;
}
