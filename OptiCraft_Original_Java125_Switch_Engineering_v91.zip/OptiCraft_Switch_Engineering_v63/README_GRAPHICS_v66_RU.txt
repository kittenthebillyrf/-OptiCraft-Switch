OptiCraft Java Lite 1.2.5 → Nintendo Switch
v64–v66: точный аудит графических вызовов

В архив добавлены:
- MINECRAFT_OPENGL_CALL_INVENTORY_v66.csv
- OPENGL_TO_SWITCH_BACKEND_CONTRACT_v66.csv
- tools/scan_minecraft_gl_refs.py
- REPORT_v64_v66_GRAPHICS_RU.md

Просканировано 1152 классов, найдено 117 уникальных
сигнатур вызовов LWJGL graphics/display/context.

Важно: это не NRO и не реализация OpenGL. Реальный Switch GPU backend пока
не написан и на консоли не проверялся.
