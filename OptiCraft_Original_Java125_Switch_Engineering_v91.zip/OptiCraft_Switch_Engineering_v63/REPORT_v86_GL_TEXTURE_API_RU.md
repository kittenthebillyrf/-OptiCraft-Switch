# OptiCraft Switch — v86: OpenGL 1.1 texture API facade

## Реализовано
- Добавлен `TextureApi` поверх `TextureStore`.
- Генерация имён текстур, создание/удаление, привязка `GL_TEXTURE_2D` и проверка `is_texture`.
- Поддержаны `glTexParameteri`-подобные параметры MIN/MAG filter и WRAP_S/WRAP_T.
- Поддержан `glPixelStorei(GL_UNPACK_ALIGNMENT, 1/2/4/8)`.
- Реализованы CPU-side операции `image_2d` и `sub_image_2d` для уровней 0, форматов Alpha/Luminance/LuminanceAlpha/RGB/RGBA и `UNSIGNED_BYTE`.
- Невалидные target, level, border, format, type и параметры отклоняются без записи в хранилище.

## Проверки
Все семь команд завершились с кодом 0 на хостовой среде:
- GL compatibility core
- LWJGL InputImplementation adapter
- Switch input JNI event bridge
- libnx platform syntax (mock API)
- Sys JNI ABI
- TextureStore upload/sub-upload
- GL Texture API facade

## Ограничения
Это API-фасад и CPU-хранилище, а не полноценный OpenGL 1.1 драйвер. Пока отсутствуют JNI-регистрация точных методов `GL11`, клиентские массивы, mipmap-уровни, форматы кроме unsigned byte, allocation-only upload с null, GPU backend и подключение текстур к растеризатору. Все проверки — host tests; Switch/NRO/JVM/Minecraft runtime не запускались.
