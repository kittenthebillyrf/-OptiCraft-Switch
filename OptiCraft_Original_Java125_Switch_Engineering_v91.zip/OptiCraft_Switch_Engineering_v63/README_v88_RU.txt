OptiCraft Java 1.2.5 + OptiFine HD U C7 → Nintendo Switch
Инженерный пакет v88

Новое:
- Client-side vertex arrays: vertex/color/texcoord/normal.
- glDrawArrays/glDrawElements CPU adapter.
- Поддержка основных скалярных типов OpenGL.
- Batch transform использует текущие projection/modelview matrices.
- Новый тест client_arrays_test.

Читайте:
- REPORT_v88_CLIENT_ARRAYS_RU.md
- VALIDATION_v88.txt
- README_v87_RU.txt

Ограничения:
Пока нет готового NRO, JVM Switch port, полного OpenGL JNI слоя и подтверждённого запуска на консоли.
