$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

if (-not $env:DEVKITPRO) {
    throw "DEVKITPRO is not set. Install devkitPro with devkitA64 and libnx."
}
$preflight = Join-Path $root "tools\preflight_switch_nro.sh"
if (-not (Test-Path (Join-Path $env:DEVKITPRO "libnx\switch_rules"))) {
    throw "libnx switch_rules not found under DEVKITPRO=$env:DEVKITPRO"
}
if (-not (Test-Path (Join-Path $env:DEVKITPRO "devkitA64\bin\aarch64-none-elf-g++.exe"))) {
    throw "devkitA64 compiler not found under DEVKITPRO=$env:DEVKITPRO"
}
if (-not (Get-Command make -ErrorAction SilentlyContinue)) {
    throw "make not found. Run from the devkitPro MSYS2 shell."
}

$env:PATH = "$env:DEVKITPRO\devkitA64\bin;$env:DEVKITPRO\tools\bin;$env:PATH"
make clean
if ($LASTEXITCODE -ne 0) { throw "make clean failed" }
make all
if ($LASTEXITCODE -ne 0) { throw "NRO build failed" }

$nro = Join-Path $root "OptiCraft.nro"
if (-not (Test-Path $nro)) { throw "Expected NRO was not produced: $nro" }

$dist = Join-Path $root "dist\switch\OptiCraft"
New-Item -ItemType Directory -Force -Path $dist | Out-Null
Copy-Item $nro (Join-Path $dist "OptiCraft.nro") -Force
Copy-Item (Join-Path $root "assets\opticraft_icon.jpg") (Join-Path $dist "opticraft_icon.jpg") -Force
Write-Host "Built first-boot NRO: $nro"
Write-Host "SD target: switch\OptiCraft\OptiCraft.nro"
