# OptiCraft Switch — этап v64–v66: графический тракт

## Результат анализа оригинального JAR
- Просканировано class-файлов Minecraft: **1152**
- Уникальных сигнатур вызовов LWJGL OpenGL/Display/GLContext: **117**
- Ссылок на эти методы в constant pool: **656**
- Сигнатур GL11: **75**
- Сигнатур Display: **17**
- Сигнатур GLContext: **1**

Полный список находится в `abi/MINECRAFT_OPENGL_CALL_INVENTORY_v66.csv`.
`abi/OPENGL_TO_SWITCH_BACKEND_CONTRACT_v66.csv` группирует каждую фактически
используемую сигнатуру по подсистеме и описывает необходимый Switch backend.

## Ключевой технический вывод
Minecraft 1.2.5 использует не только базовые текстуры и треугольники, но и
legacy fixed-function OpenGL: матричный стек, `glBegin/glEnd`, display lists,
client-side vertex arrays, fog/light state и текстурные операции.
Прямого соответствия «вызов GL → libnx framebuffer» нет. Текущий диагностический
framebuffer умеет показать тестовую картинку, но он не является OpenGL context
и не может отрисовать Minecraft.

Для реального порта нужен один из двух путей:
1. OpenGL compatibility layer, реализованный поверх доступного на Horizon GPU API;
2. перевод legacy OpenGL состояния и draw calls в собственный shader/command backend.

В текущем исходном наборе подтверждены libnx framebuffer/HID API, но не готовый
OpenGL runtime для Horizon. Mesa source tree сам по себе не доказывает наличие
готового драйвера Switch/NVN. Поэтому backend не объявлен реализованным.

## Следующие обязательные задачи
1. Выбрать и проверить доступный на целевой прошивке GPU submission path.
2. Реализовать context, swap/present и resource lifetime.
3. Реализовать compatibility state: matrices, immediate mode, display lists,
   texture objects, client arrays, fog/light/blend/depth.
4. Реализовать GL queries и NIO buffer JNI bridge.
5. Прогнать GL smoke tests на консоли, затем Minecraft main-menu bootstrap.

## Честный статус
Это точная карта графических требований и архитектурный контракт, а не готовый
OpenGL backend. NRO не собирался и теста на Nintendo Switch не было.
