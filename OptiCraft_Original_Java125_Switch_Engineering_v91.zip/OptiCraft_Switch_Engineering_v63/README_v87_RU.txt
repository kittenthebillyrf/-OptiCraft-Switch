OptiCraft Java 1.2.5 + OptiFine HD U C7 → Nintendo Switch
Инженерный пакет v87

Новое в v87:
- CPU rasterizer теперь умеет использовать текстуры TextureStore.
- RGBA текстуры умножаются на цвет вершин.
- UV interpolation использует perspective correction (1/w).
- Добавлен software_renderer_texture_test.
- Исправлена линковка GL compatibility test.

Начало:
1) Прочитай REPORT_v87_TEXTURED_RASTERIZER_RU.md.
2) Прочитай VALIDATION_v87.txt.
3) Запускай тесты из tests/run_*.sh через bash.
4) Для сборки Switch нужны devkitPro/devkitA64/libnx; локальные host-тесты не создают NRO.

Важно:
Это всё ещё инженерный слой порта. Готового NRO и подтверждённого запуска на Switch нет.
Оригинальный minecraft.jar не модифицируется и не подменяется клоном.
