# Отчёт v67–v70 — JNI-мост ввода

## Что реально добавлено
- C++ event bridge поверх существующего Npad mapping.
- JNI API для обновления состояния контроллера, получения событий, проверки
  состояния клавиш/кнопок мыши и координат виртуального курсора.
- Правый стик двигает виртуальный курсор с ограничением по границам экрана.
- Проверены переходы key-down/key-up, удержание без повторных событий,
  mouse state, движение курсора и reset.
- Добавлен Java ABI-класс `org.lwjgl.switchport.SwitchInputBridge`.

## Тесты
- Sys JNI host smoke test: PASS.
- Input JNI host smoke test: PASS.
- Это host JVM + g++ тесты. Они не доказывают работу на ARM64/Horizon.

## Найденная интеграционная деталь
По bytecode именно оригинального LWJGL 2.9.4 подтверждены форматы:
- Keyboard event: 18 байт (`int, byte, int, long, byte`).
- Mouse event: 22 байта (`byte, byte, int, int, int, long`).

Следующий код должен сериализовать события в эти форматы и реализовать
`InputImplementation`. JNI event bridge сам по себе ещё не подключает Minecraft
к физическим кнопкам Switch.

## Не выполнено
- Полный Java `InputImplementation` / `DisplayImplementation`.
- Реальный HID poll loop на Horizon.
- OpenGL compatibility renderer и GPU submission.
- Загрузка native library в целевой JVM.
- ARM64/Horizon сборка, NRO, тест запуска Minecraft.
