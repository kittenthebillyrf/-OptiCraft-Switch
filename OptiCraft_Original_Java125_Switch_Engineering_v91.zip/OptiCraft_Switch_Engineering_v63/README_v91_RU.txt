OptiCraft Switch v91 — первый NRO-кандидат

Новый Makefile собирает изолированный диагностический NRO: OptiCraft.nro.
Он показывает старт приложения, состояние опроса контроллера и клавиши A/Plus.
Он НЕ запускает JVM и Minecraft; эти статусы на экране честно помечены как не подключённые.

Сборка:
  ./build_switch.sh
или Windows:
  .\build_windows.ps1

Требуется devkitPro + devkitA64 + libnx.
Файл для SD:
  switch/OptiCraft/OptiCraft.nro

Плитка обычного HOME Menu — отдельная задача, решаемая отдельным forwarder NSP.
Сам NRO её не устанавливает. Подробности: docs/HOME_MENU_FORWARDER_RU.md.
