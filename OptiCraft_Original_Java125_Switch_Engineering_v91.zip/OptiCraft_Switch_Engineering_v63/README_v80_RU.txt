OptiCraft Java Lite 1.2.5 → Nintendo Switch
v75–v80: input/touch integration + GL compatibility core + CPU rasterizer.

Требования для host tests: JDK, g++, Python 3 (только для дополнительных инструментов).

Запустить:
  bash tests/run_sys_native_test.sh
  bash tests/run_input_jni_test.sh
  bash tests/run_input_implementation_test.sh
  bash tests/run_gl_compat_core_test.sh
  bash tests/run_platform_syntax_test.sh

Внимание:
- Host tests do not prove Horizon compatibility.
- NRO has not been built.
- No Switch runtime test has been performed.
- Software rasterizer is an initial subset, not complete Minecraft OpenGL support.


v85: TextureStore расширен поддержкой GL_UNPACK_ALIGNMENT и обновления областей текстуры (sub_upload). Отчёт: REPORT_v85_SUBIMAGE_UNPACK_RU.md. Тест: tests/run_texture_store_test.sh.


v86: добавлен CPU-side OpenGL texture API facade (gen/delete/bind/is, parameters, unpack alignment, image_2d/sub_image_2d). Отчёт: REPORT_v86_GL_TEXTURE_API_RU.md; тест: tests/run_gl_texture_api_test.sh.
