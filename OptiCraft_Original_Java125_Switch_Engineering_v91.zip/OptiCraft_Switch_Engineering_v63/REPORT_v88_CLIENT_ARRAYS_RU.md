# OptiCraft Switch — инженерный этап v88

## Крупный блок: OpenGL 1.1 client-side vertex arrays

Добавлен `ClientArrays`:
- хранение отдельных состояний указателей Vertex, Color, Texture Coordinate и Normal;
- `enable/disable` для четырёх соответствующих client states;
- обработка массивов `GL_BYTE`, `GL_UNSIGNED_BYTE`, `GL_SHORT`, `GL_UNSIGNED_SHORT`, `GL_INT`, `GL_UNSIGNED_INT`, `GL_FLOAT`, `GL_DOUBLE`;
- stride в байтах и tightly-packed режим при stride=0;
- `draw_arrays` и `draw_elements`;
- типы индексов unsigned byte/short/int;
- сборка `DrawBatch` для точек, линий, line loop/strip, треугольников, triangle strip/fan и quads;
- безопасное чтение невыравненных элементов через memcpy;
- проверки неподдерживаемого режима, отрицательных count/first, неверного index type, отсутствующего vertex array и чрезмерного количества элементов.

Добавлен `CompatCore::transform(DrawBatch&)`, чтобы batches, собранные не через `glBegin/glEnd`, проходили через тот же modelview/projection transform.

## Проверка
`tests/client_arrays_test.cpp` проверяет interleaved arrays, byte stride, цвет, UV, triangle strip, indexed triangles, типы индексов, transform и некорректные аргументы.

Полный список результатов — в `VALIDATION_v88.txt`.

## Точность и ограничения
Это внутренний CPU-side слой, не полный OpenGL ABI и не готовые JNI entry points. Сейчас:
- указатели считаются адресами client memory; VBO/buffer objects не поддерживаются;
- caller обязан обеспечить, чтобы переданные указатели действительно покрывали запрошенный диапазон памяти — OpenGL API сам по себе не передаёт размер allocation;
- нет `glInterleavedArrays`, `glArrayElement`, display lists и сохранения client attrib stacks;
- нормали пока не проходят полноценный fixed-function lighting pipeline;
- POINTS и LINES создают соответствующие индексы, но текущий software rasterizer полноценно растеризует только треугольники;
- типы/режимы ещё нужно связать с точными native signatures оригинального LWJGL 2.9.4.

Семантика pointer/stride и indexed draw сверялась с OpenGL 1.1 reference и документацией `glVertexPointer` / `glDrawElements`: Khronos spec, Microsoft Learn. См. внешние ссылки в отчёте проекта.

## Статус порта
Хостовые тесты подтверждают работу этого инженерного слоя, но не доказывают сборку NRO или запуск игры на Horizon OS. JVM, Switch GPU backend, JNI OpenGL entry points и реальный запуск Minecraft остаются незавершёнными.
