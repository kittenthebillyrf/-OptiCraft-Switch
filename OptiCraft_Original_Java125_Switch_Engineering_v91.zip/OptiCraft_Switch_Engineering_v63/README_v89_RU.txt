OptiCraft Java 1.2.5 + OptiFine HD U C7 → Nintendo Switch
Инженерный пакет v89

Новое:
- alpha test / blend factors / depth compare в CPU rasterizer;
- ограниченный набор GL state queries;
- interleaved client arrays + ArrayElement;
- integer vertex/color attribute conversion;
- общий LegacyGLContext (fixed-function + arrays + textures + renderer);
- RGBA8 framebuffer blit и libnx platform_present_rgba8.

Читайте:
- REPORT_v89_GL_PIPELINE_INTEGRATION_RU.md
- VALIDATION_v89.txt
- README_v88_RU.txt и предыдущие отчёты.

Важно:
Это подготовительный порт-слой. Полный OpenGL 1.1, JVM/HotSpot для Horizon, звук, интеграция оригинального Minecraft в runtime, NRO и запуск на консоли пока не готовы.
