# OptiCraft Switch — v54–v57: input adapter + diagnostic backend hardening

## Итог этапа

Подготовлен следующий инженерный пакет. Он продвигает подготовку до ориентировочных 80%: появился независимый, проверяемый адаптер управления и расширен исходный диагностический backend libnx.

## Что добавлено

### 1. Обновлён диагностический Switch backend
`src/switch_diagnostic_main.cpp`:
- инициализирует HID и явно инициализирует Npad;
- читает контроллер в handheld-режиме, затем пробует Player 1 для docked-режима;
- получает значения обоих стиков;
- отображает стики и нажатия кнопок на framebuffer;
- использует linear framebuffer и проверяет нулевой указатель кадра;
- выход по Plus.

Символы HID/Npad/framebuffer сверены с загруженными заголовками libnx. Это всё ещё диагностическая программа, не Minecraft и не OpenGL.

### 2. Добавлен LWJGL input adapter
`include/input_adapter.hpp` и `src/input_adapter.cpp`:
- левый стик -> WASD с deadzone;
- B -> Escape;
- X -> E (инвентарь-кандидат);
- Y -> Q;
- D-pad -> стрелки;
- L -> правая кнопка мыши (разместить блок);
- R -> левая кнопка мыши (сломать блок);
- A -> левая кнопка мыши (выбор/подтверждение);
- выдаёт только переходы key-down/key-up и mouse-down/mouse-up, а не повторяет события каждый кадр.

Это изолированный адаптер: его события пока не подключены к JVM/LWJGL runtime. Схему кнопок можно будет изменить через настройки.

### 3. Добавлены build scripts
- `Makefile` для devkitPro/libnx.
- `build_windows.ps1` для запуска сборки из Windows с установленным devkitPro.
- `build_switch.sh` для shell-сборки.

### 4. Добавлены тесты
- `tests/input_adapter_test.cpp` проверяет нажатие, удержание, отпускание WASD и L/R.
- Host-side C++ тест скомпилирован локальным `g++` с `-Wall -Wextra -Werror` и выполнен успешно.
- `switch_diagnostic_main.cpp` прошёл syntax-only проверку с временными mock-заголовками. Это не является сборкой против настоящего libnx.
- В `tests/` сохранены логи и mock-заголовок.

## Что подтверждено

- Host-side input adapter: compile PASS.
- Host-side input adapter tests: PASS.
- C++ syntax-only check диагностического main: PASS against mock headers.
- Used libnx API identifiers: found in uploaded libnx headers.
- Actual devkitA64/libnx build: NOT RUN.
- NRO generation and Switch hardware test: NOT RUN.

## Ограничения

- В среде нет `aarch64-none-elf-g++`, devkitA64 или devkitPro toolchain.
- Диагностический backend пока не создаёт GL context.
- JNI exports LWJGL ещё не реализованы.
- JVM/HotSpot на Horizon OS не запускается.
- Minecraft main menu и world loading не проверялись.

## Оценка прогресса

**Около 80% подготовительной инженерной части**: зависимость и ABI-карта, системные API, backend scaffold, input event adapter, host tests и инструкции сборки подготовлены.

Это не 80% готовности игрового порта. Исполняемый порт пока не собран; следующий реальный рубеж — получить diagnostic NRO на devkitA64 и проверить его на Switch, затем реализовать JNI и настоящий графический backend.
