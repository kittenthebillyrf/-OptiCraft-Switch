OptiCraft Switch v58-v60 package.

Contains the first tested JNI implementation for two native methods in the original bundled LWJGL 2.9.4 BufferUtils class:
- zeroBuffer0(Buffer,long,long)
- getBufferAddress(Buffer)

The host integration test loads the actual lwjgl.jar extracted from the original OptiCraft archive and passes.

This is not a Switch build, not an NRO, not a JVM port, and not a Minecraft build.
Read REPORT_v58_v60_RU.md and docs/JNI_BUFFERUTILS_IMPLEMENTATION.md.

v87: см. README_v87_RU.txt, REPORT_v87_TEXTURED_RASTERIZER_RU.md и VALIDATION_v87.txt.

v88: см. README_v88_RU.txt, REPORT_v88_CLIENT_ARRAYS_RU.md и VALIDATION_v88.txt.

v89: см. README_v89_RU.txt, REPORT_v89_GL_PIPELINE_INTEGRATION_RU.md и VALIDATION_v89.txt.

v90: см. README_v90_RU.txt, REPORT_v90_JAVA_BOOTSTRAP_RU.md и ORIGINAL_PACKAGE_AUDIT_v90.txt.


v91: added isolated first-boot NRO source, icon, toolchain preflight, build scripts, host syntax test and HOME Menu forwarder design note. NRO not built here: devkitA64/libnx/elf2nro are unavailable in this environment.
