# OptiCraft Switch — крупный блок v75–v80

## 1. Java input path
Добавлен `SwitchInputImplementation`, реализующий исходный интерфейс
`org.lwjgl.opengl.InputImplementation` из bundled LWJGL 2.9.4.
Проверены poll/read пути клавиатуры и мыши с точными event layouts.
Класс компилируется против оригинального LWJGL JAR.

## 2. Touchscreen path
- Платформенный libnx слой инициализирует touchscreen один раз.
- Считывает первый активный touch point через `hidGetTouchScreenStates`.
- JNI bridge принимает touch x/y/down.
- Touch преобразуется в виртуальный курсор и left mouse down/up.
- Координаты ограничиваются размерами целевого окна.

Важно: platform source проверен синтаксически против mock API; реальный
devkitA64/libnx build и чтение touch на консоли не выполнялись.

## 3. GL compatibility core
Добавлено ядро совместимости для ограниченного legacy OpenGL subset:
- ModelView / Projection / Texture matrix stacks.
- Identity, push/pop, translate, rotate, scale, ortho.
- Immediate-mode begin/end и атрибуты vertex/color/texcoord/normal.
- Преобразование вершин в clip space через Projection * ModelView.
- Конвертация triangles, triangle strip/fan, quads, lines и line loop
  в индексированные примитивы.
- Базовое состояние depth/blend/cull/texture/fog/lighting/alpha,
  viewport, clear color/depth, depth func, blend func.

## 4. CPU software rasterizer
Добавлен тестируемый CPU triangle rasterizer:
- viewport transform;
- barycentric coverage;
- interpolated vertex color;
- depth buffer и depth test;
- color/depth clear.

Это настоящий программный rasterizer для простых треугольников, но не
полная реализация OpenGL 1.2. Он пока не покрывает текстурирование,
lighting/fog shaders, display lists, pixel operations, complete GL query
semantics, blending equations и все вызовы из Minecraft.

## 5. Проверки
Host tests:
- Sys JNI.
- Input JNI.
- Java InputImplementation.
- GL compatibility core + software triangle rasterizer.
- Platform source syntax check against mock libnx API.

Все перечисленные host tests должны проходить в окружении с JDK и g++.
Они не являются тестом на Switch.

## 6. Оставшиеся блокеры
- Подключить platform HID loop к работающему JVM thread / Java adapter.
- Native library loading / JVM bootstrap на Horizon.
- Полная OpenGL 1.2 compatibility: textures, display lists, fixed-function
  lighting/fog, client arrays, queries/readback, blending and pixel store.
- Реальный GPU backend либо интеграция проверенного Switch GPU stack.
- Audio, AWT image pipeline, filesystem and networking integration.
- devkitA64/libnx cross-build, NRO packaging and console runtime tests.

## Итог
Подготовка существенно продвинулась: ввод теперь имеет Java adapter,
touchscreen путь подключён в платформенном источнике, а legacy GL имеет
первое исполняемое compatibility ядро и CPU triangle rasterizer.
Полноценный Minecraft на Switch ещё не запускается.
