# OptiCraft Switch — инженерный этап v87

## Что добавлено

### Текстурированный CPU-рендеринг
- `SoftwareRenderer` получил новый overload `draw(batch, state, textures, texture_id)`.
- Для включённого `texture_2d` выполняется выборка из `TextureStore` и умножение RGBA текстуры на интерполированный цвет вершины (GL_MODULATE-подобный базовый путь).
- UV координаты интерполируются с коррекцией по `1/w`, чтобы уменьшить перспективные искажения.
- Существующий нетекстурированный `draw(batch, state)` сохранён без изменения публичного вызова.
- Добавлен тест с четырёхцветной текстурой, проверяющий выборку разных участков треугольника и обратную совместимость.

### Исправлена сборка теста GL compatibility
- `run_gl_compat_core_test.sh` теперь линкует `texture_store.cpp`, необходимый новому renderer.
- Добавлен отдельный запуск `run_software_renderer_texture_test.sh`.

## Границы реализации
Это CPU reference renderer, а не готовый GPU/OpenGL backend для Horizon OS. Пока не реализованы полноценный OpenGL 1.1 state machine, blending, alpha test, mipmap levels, display lists, client arrays и JNI-экспорт texture entry points. Перспективная коррекция UV реализована, clipping полного примитива за пределами clip-space и точные правила top-left rasterization пока не реализованы.

## Проверки
См. `VALIDATION_v87.txt`. Хостовые тесты не доказывают запуск на Nintendo Switch.
