#include <switch.h>
#include <cstdio>

namespace {

void draw_screen(bool button_a_seen, unsigned long long frames) {
    consoleClear();

    std::printf("============================================\n");
    std::printf("          OPTICRAFT — FIRST BOOT\n");
    std::printf("       Minecraft Java 1.2.5 / OptiFine\n");
    std::printf("============================================\n\n");

    std::printf("[OK] NRO entry point is running.\n");
    std::printf("[OK] libnx application loop is active.\n");
    std::printf("[OK] Controller input polling is active.\n\n");

    std::printf("CURRENT BUILD: v91 / first-NRO prototype\n\n");

    std::printf("JAVA RUNTIME: NOT CONNECTED\n");
    std::printf("MINECRAFT.JAR: NOT LOADED\n");
    std::printf("LWJGL JNI:      NOT CONNECTED\n\n");

    std::printf("This screen confirms only that the Switch can\n");
    std::printf("start the OptiCraft homebrew NRO. It does not\n");
    std::printf("claim that Minecraft is already running.\n\n");

    std::printf("A button detected: %s\n", button_a_seen ? "YES" : "NO");
    std::printf("Frames: %llu\n\n", frames);

    std::printf("A     - mark input test\n");
    std::printf("+     - exit to Homebrew Menu\n");

    consoleUpdate(nullptr);
}

} // namespace

int main(int argc, char** argv) {
    (void)argc;
    (void)argv;

    consoleInit(nullptr);

    padConfigureInput(1, HidNpadStyleSet_NpadStandard);
    PadState pad{};
    padInitializeDefault(&pad);

    bool button_a_seen = false;
    unsigned long long frames = 0;

    while (appletMainLoop()) {
        padUpdate(&pad);
        const u64 buttons_down = padGetButtonsDown(&pad);

        if ((buttons_down & HidNpadButton_Plus) != 0) {
            break;
        }

        if ((buttons_down & HidNpadButton_A) != 0) {
            button_a_seen = true;
        }

        ++frames;
        draw_screen(button_a_seen, frames);
    }

    consoleExit(nullptr);
    return 0;
}
