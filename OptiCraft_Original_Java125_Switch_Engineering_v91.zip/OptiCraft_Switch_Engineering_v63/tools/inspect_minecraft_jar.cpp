#include "java_runtime_bootstrap.hpp"
#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>
int main(int argc,char** argv) {
    if(argc!=2){std::cerr<<"usage: inspect_minecraft_jar <minecraft.jar>\\n";return 2;}
    std::ifstream in(argv[1],std::ios::binary);
    if(!in){std::cerr<<"cannot open jar\\n";return 2;}
    std::vector<std::uint8_t> bytes((std::istreambuf_iterator<char>(in)),{});
    const auto report=opti::runtime::inspect_jar(bytes.data(),bytes.size());
    if(!report.valid){std::cerr<<"INVALID: "<<report.error<<"\\n";return 1;}
    std::cout<<"VALID JAR\\nentries="<<report.entries.size()
             <<" classes="<<report.class_count<<" resources="<<report.resource_count
             <<" minecraft_main="<<(report.has_minecraft_main?"yes":"no")<<"\\n";
}
