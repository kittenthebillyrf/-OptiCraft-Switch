# OptiCraft Switch — v58–v60: первый реальный JNI-модуль LWJGL

## Итог

Реализованы две native-функции `org.lwjgl.BufferUtils` из LWJGL, поставляемого вместе с оригинальным OptiCraft. Впервые проверен не только отдельный C++ код, но и его загрузка настоящей Java VM с оригинальным `lwjgl.jar`.

## Что реализовано

### `zeroBuffer0(Buffer, long, long)`
- Получает адрес direct NIO buffer через JNI.
- Поддерживает ByteBuffer, ShortBuffer, CharBuffer, IntBuffer, FloatBuffer, LongBuffer и DoubleBuffer.
- Корректно трактует offset/length как байты.
- Переводит capacity typed buffer в байты.
- Проверяет отрицательные и выходящие за границы диапазоны.
- Обнуляет только запрошенный участок.

### `getBufferAddress(Buffer)`
- Возвращает адрес direct NIO buffer как `jlong`.
- Отказывается от null и недиректных буферов с Java exception.

### Регистрация JNI
Используется `JNI_OnLoad` и `RegisterNatives` с точными JVM-дескрипторами из исходного LWJGL JAR. Для host-теста имя класса переключается compile define; для реального LWJGL используется `org/lwjgl/BufferUtils`.

## Проверки

- JNI shared library compiled with host `g++`: PASS.
- Java test compiled with JDK: PASS.
- Test loaded the actual bundled `lwjgl.jar`: PASS.
- Actual `BufferUtils.zeroBuffer(ByteBuffer)`: PASS.
- Actual `BufferUtils.zeroBuffer(IntBuffer)`: PASS.
- Actual `getBufferAddress(Buffer)`: PASS.
- Position/limit range behavior: PASS.
- Host input adapter tests from v57: PASS.
- Switch NRO build: NOT RUN — devkitA64/libnx toolchain unavailable here.
- Horizon execution: NOT RUN.

Лог реального теста находится в `tests/ORIGINAL_LWJGL_ABI_TEST_LOG.txt`. Повторный запуск — `tests/run_original_lwjgl_abi_test.sh`.

## Ограничения

Это первый небольшой фрагмент JNI, а не вся LWJGL реализация. GL11, GL13, Display, Sys, Keyboard/Mouse, OpenAL и библиотечный загрузчик Horizon ещё не реализованы. JVM на Switch не запускалась. Диагностический NRO всё ещё не собран.

## Прогресс

Оценка подготовительной и прототипной инженерной части: **примерно 85%**. Важный переход: появились две работающие JNI-реализации, проверенные против настоящего LWJGL JAR. До 90% остаётся пройти target build и проверить native loading/Display path на devkitA64 и Switch.

Это не 85% готовности игрового порта. Minecraft на Switch пока не запускается.
