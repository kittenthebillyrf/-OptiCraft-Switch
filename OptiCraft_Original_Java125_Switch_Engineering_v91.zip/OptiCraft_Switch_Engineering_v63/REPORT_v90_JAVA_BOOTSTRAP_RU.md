# OptiCraft Switch — инженерный этап v90: Java Runtime bootstrap

## Что добавлено

### 1. Проверяемая структура оригинального JAR
`inspect_jar()` разбирает ZIP End Of Central Directory и central directory без распаковки файлов:
- проверяет сигнатуры и границы ZIP-структур;
- проверяет методы сжатия Store/Deflate и отбрасывает шифрованные/ZIP64 архивы;
- проверяет локальные заголовки записей;
- считает class/resource entries;
- требует наличие `net/minecraft/client/Minecraft.class`.

Добавлен `tools/inspect_minecraft_jar.cpp` и тест против реального minecraft.jar из пользовательского исходного архива.

Результат для исходного minecraft.jar:
- 1 566 записей;
- 1 152 class-файла;
- 414 ресурсов;
- найден `net/minecraft/client/Minecraft.class`;
- class-file major version всех 1 152 классов: 49 (Java 5 bytecode).

Это проверка структуры архива и наличия главного класса, не полная проверка CRC всех сжатых данных и не исполнение байткода.

### 2. Java launch plan
Добавлен `make_launch_plan()`:
- главный класс `net.minecraft.client.Minecraft`;
- classpath для minecraft.jar, lwjgl.jar, lwjgl_util.jar, jinput.jar и switchport.jar;
- передача пользовательских аргументов;
- проверка корневого пути и разделителя classpath.

### 3. Bootstrap contract
Добавлен `bootstrap()` с явными callback этапами:
1. проверка всех файлов classpath;
2. вызов загрузчика VM;
3. передача main class и аргументов в Java main invocation.

Это интерфейсный контракт и тестируемая последовательность. Callback `load_vm` пока не подключён к реальной JVM, а `invoke_main` не исполняет Java самостоятельно.

### 4. Сборка Java-адаптера
Добавлен `tools/build_switchport_jar.sh`. Скрипт требует компилятор, который умеет генерировать Java 6 bytecode (`-source 1.6 -target 1.6`), и после сборки проверяет major version не выше 50. Установленный в текущей среде компилятор не подтверждён как совместимый с Java 6, поэтому switchport.jar здесь не объявляется собранным.

## Проверка оригинального пакета
`tools/audit_original_package.py` проверил исходный пользовательский архив:
- minecraft.jar — 4 136 777 байт, SHA-256 `7b296baec50bd3985013dbae72e9f4af079c364cca4b44b0393d7058bc281f3b`;
- lwjgl.jar — 1 047 168 байт;
- lwjgl_util.jar — 173 887 байт;
- jinput.jar — 227 833 байт.
Все четыре файла открываются как ZIP/JAR. Внешний архив также содержит 105 Windows DLL/EXE файлов — они не являются Switch runtime и не должны переноситься как есть.

Полный вывод — `ORIGINAL_PACKAGE_AUDIT_v90.txt`.

## Тестирование
`VALIDATION_v90.txt` содержит полный список host-side проверок. Новые тесты:
- `java_runtime_bootstrap_test.cpp`: success/failure path для файлов classpath, VM callback и main callback;
- `run_original_minecraft_jar_inspection.sh`: проверка настоящего minecraft.jar из исходного архива.

## Что ещё отсутствует
- Реальная JVM/HotSpot для Horizon OS;
- реализация callback `load_vm` через настоящий `JNI_CreateJavaVM`/эквивалент;
- classloader, работающий с SDMC и оригинальными JAR на Switch;
- JNI registration всех нужных LWJGL методов;
- Java Sound, системные свойства и файловые потоки;
- NRO, собранный с JVM и игрой;
- запуск на консоли.

## Оценка
Этот этап закрывает часть подготовки запуска и проверку исходного пакета. Он не превращает bootstrap contract в JVM. Общая инженерная оценка порта после v90: **около 20%**, с высокой неопределённостью. Рабочий билд Minecraft по-прежнему отсутствует.

## Примечание по OpenJDK
Официальная документация OpenJDK описывает сборку как отдельную конфигурацию build/target с раздельными build tools и target toolchain; ОС, не поддерживаемые основным проектом, требуют отдельного port work. Это подтверждает, что Switch runtime нельзя получить одной компоновкой готовых Linux ARM64 объектов. См. OpenJDK Build documentation.
