#include "world_save_reader.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <fstream>
#include <limits>
#include <sstream>
#include <utility>
#include <zlib.h>

namespace opti::world {
namespace {

constexpr std::size_t kMaxNbtBytes = 64u * 1024u * 1024u;
constexpr std::int32_t kMaxNbtItems = 4 * 1024 * 1024;
constexpr unsigned kMaxNbtDepth = 64;
constexpr std::size_t kSectorBytes = 4096;
constexpr std::size_t kRegionHeaderBytes = 2 * kSectorBytes;

void set_error(std::string* error, const std::string& value) {
    if (error) *error = value;
}

std::uint16_t read_u16(const std::uint8_t* p) {
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(p[0]) << 8) | p[1]);
}

std::uint32_t read_u32(const std::uint8_t* p) {
    return (static_cast<std::uint32_t>(p[0]) << 24) |
           (static_cast<std::uint32_t>(p[1]) << 16) |
           (static_cast<std::uint32_t>(p[2]) << 8) |
            static_cast<std::uint32_t>(p[3]);
}

std::int32_t as_i32(const NbtTag* tag, std::int32_t fallback = 0) {
    if (!tag) return fallback;
    if (tag->type == 1 || tag->type == 2 || tag->type == 3 || tag->type == 4)
        return static_cast<std::int32_t>(tag->integer);
    return fallback;
}

std::int64_t as_i64(const NbtTag* tag, std::int64_t fallback = 0) {
    if (!tag) return fallback;
    if (tag->type == 1 || tag->type == 2 || tag->type == 3 || tag->type == 4)
        return tag->integer;
    return fallback;
}

class NbtParser {
public:
    explicit NbtParser(const std::vector<std::uint8_t>& input) : input_(input) {}

    bool parse(NbtTag& root, std::string* error) {
        std::uint8_t type = 0;
        if (!u8(type) || type != 10) return fail(error, "NBT root is not TAG_Compound");
        std::string name;
        if (!string(name)) return fail(error, "Truncated NBT root name");
        if (!payload(type, name, 0, root)) return fail(error, message_);
        if (position_ != input_.size()) return fail(error, "Trailing bytes after NBT root");
        return true;
    }

private:
    const std::vector<std::uint8_t>& input_;
    std::size_t position_ = 0;
    std::string message_;

    bool fail(std::string* error, const std::string& why) {
        set_error(error, why);
        return false;
    }

    bool take(std::size_t count, const std::uint8_t*& out) {
        if (count > input_.size() - position_) return false;
        out = input_.data() + position_;
        position_ += count;
        return true;
    }

    bool u8(std::uint8_t& value) {
        const std::uint8_t* p = nullptr;
        if (!take(1, p)) return false;
        value = p[0];
        return true;
    }

    bool u16(std::uint16_t& value) {
        const std::uint8_t* p = nullptr;
        if (!take(2, p)) return false;
        value = read_u16(p);
        return true;
    }

    bool u32(std::uint32_t& value) {
        const std::uint8_t* p = nullptr;
        if (!take(4, p)) return false;
        value = read_u32(p);
        return true;
    }

    bool u64(std::uint64_t& value) {
        const std::uint8_t* p = nullptr;
        if (!take(8, p)) return false;
        value = (static_cast<std::uint64_t>(read_u32(p)) << 32) | read_u32(p + 4);
        return true;
    }

    bool string(std::string& value) {
        std::uint16_t length = 0;
        const std::uint8_t* p = nullptr;
        if (!u16(length) || !take(length, p)) return false;
        value.assign(reinterpret_cast<const char*>(p), length);
        return true;
    }

    bool payload(std::uint8_t type, const std::string& name,
                 unsigned depth, NbtTag& output) {
        if (depth > kMaxNbtDepth) {
            message_ = "NBT nesting depth limit exceeded";
            return false;
        }
        output = NbtTag{};
        output.type = type;
        output.name = name;
        const std::uint8_t* p = nullptr;
        std::uint32_t count = 0;
        switch (type) {
        case 1: {
            std::uint8_t v = 0;
            if (!u8(v)) return truncated();
            output.integer = static_cast<std::int8_t>(v);
            return true;
        }
        case 2: {
            std::uint16_t v = 0;
            if (!u16(v)) return truncated();
            output.integer = static_cast<std::int16_t>(v);
            return true;
        }
        case 3: {
            std::uint32_t v = 0;
            if (!u32(v)) return truncated();
            output.integer = static_cast<std::int32_t>(v);
            return true;
        }
        case 4: {
            std::uint64_t v = 0;
            if (!u64(v)) return truncated();
            output.integer = static_cast<std::int64_t>(v);
            return true;
        }
        case 5: {
            std::uint32_t bits = 0;
            float value = 0;
            if (!u32(bits)) return truncated();
            std::memcpy(&value, &bits, sizeof(value));
            output.decimal = value;
            return true;
        }
        case 6: {
            std::uint64_t bits = 0;
            double value = 0;
            if (!u64(bits)) return truncated();
            std::memcpy(&value, &bits, sizeof(value));
            output.decimal = value;
            return true;
        }
        case 7:
            if (!u32(count) || static_cast<std::int32_t>(count) < 0 ||
                count > kMaxNbtItems || !take(count, p)) return bad_length();
            output.bytes.assign(p, p + count);
            return true;
        case 8:
            if (!string(output.string_value)) return truncated();
            return true;
        case 9: {
            if (!u8(output.list_element_type) || !u32(count) ||
                static_cast<std::int32_t>(count) < 0 || count > kMaxNbtItems)
                return bad_length();
            if (output.list_element_type == 0 && count != 0) {
                message_ = "Invalid non-empty TAG_List of TAG_End";
                return false;
            }
            output.children.reserve(count);
            for (std::uint32_t i = 0; i < count; ++i) {
                NbtTag child;
                if (!payload(output.list_element_type, "", depth + 1, child)) return false;
                output.children.push_back(std::move(child));
            }
            return true;
        }
        case 10:
            for (;;) {
                std::uint8_t child_type = 0;
                if (!u8(child_type)) return truncated();
                if (child_type == 0) return true;
                if (child_type > 12) {
                    message_ = "Unknown NBT tag type";
                    return false;
                }
                std::string child_name;
                if (!string(child_name)) return truncated();
                NbtTag child;
                if (!payload(child_type, child_name, depth + 1, child)) return false;
                output.children.push_back(std::move(child));
            }
        case 11:
            if (!u32(count) || static_cast<std::int32_t>(count) < 0 ||
                count > kMaxNbtItems || count > (input_.size() - position_) / 4)
                return bad_length();
            output.ints.reserve(count);
            for (std::uint32_t i = 0; i < count; ++i) {
                std::uint32_t v = 0;
                if (!u32(v)) return truncated();
                output.ints.push_back(static_cast<std::int32_t>(v));
            }
            return true;
        case 12:
            if (!u32(count) || static_cast<std::int32_t>(count) < 0 ||
                count > kMaxNbtItems || count > (input_.size() - position_) / 8)
                return bad_length();
            output.longs.reserve(count);
            for (std::uint32_t i = 0; i < count; ++i) {
                std::uint64_t v = 0;
                if (!u64(v)) return truncated();
                output.longs.push_back(static_cast<std::int64_t>(v));
            }
            return true;
        default:
            message_ = "Unsupported NBT tag type";
            return false;
        }
    }

    bool truncated() { message_ = "Truncated NBT payload"; return false; }
    bool bad_length() { message_ = "Invalid or excessive NBT array/list length"; return false; }
};

bool read_file(const std::string& path, std::vector<std::uint8_t>& output,
               std::string* error) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) {
        set_error(error, "Cannot open file: " + path);
        return false;
    }
    const std::streamoff size = file.tellg();
    if (size < 0 || static_cast<std::uint64_t>(size) > kMaxNbtBytes * 4u) {
        set_error(error, "Invalid or excessive file size: " + path);
        return false;
    }
    output.resize(static_cast<std::size_t>(size));
    file.seekg(0, std::ios::beg);
    if (!output.empty() && !file.read(reinterpret_cast<char*>(output.data()), size)) {
        set_error(error, "Failed to read file: " + path);
        return false;
    }
    return true;
}

bool inflate_data(const std::uint8_t* input, std::size_t input_size,
                  int window_bits, std::vector<std::uint8_t>& output,
                  std::string* error) {
    if (input_size > std::numeric_limits<uInt>::max()) {
        set_error(error, "Compressed payload is too large for zlib");
        return false;
    }
    z_stream stream{};
    stream.next_in = const_cast<Bytef*>(reinterpret_cast<const Bytef*>(input));
    stream.avail_in = static_cast<uInt>(input_size);
    if (inflateInit2(&stream, window_bits) != Z_OK) {
        set_error(error, "zlib inflateInit2 failed");
        return false;
    }
    std::array<std::uint8_t, 64 * 1024> buffer{};
    int status = Z_OK;
    while (status == Z_OK) {
        stream.next_out = buffer.data();
        stream.avail_out = static_cast<uInt>(buffer.size());
        status = inflate(&stream, Z_NO_FLUSH);
        const std::size_t produced = buffer.size() - stream.avail_out;
        if (produced > kMaxNbtBytes - output.size()) {
            inflateEnd(&stream);
            set_error(error, "Decompressed NBT exceeds safety limit");
            return false;
        }
        output.insert(output.end(), buffer.begin(), buffer.begin() + produced);
    }
    inflateEnd(&stream);
    if (status != Z_STREAM_END) {
        set_error(error, "Invalid compressed NBT payload (zlib error " +
                         std::to_string(status) + ")");
        return false;
    }
    return true;
}

bool decode_nbt_payload(const std::uint8_t* data, std::size_t size,
                        int compression, NbtTag& root, std::string* error) {
    std::vector<std::uint8_t> decoded;
    if (compression == 1) {
        if (!inflate_data(data, size, 15 + 16, decoded, error)) return false;
    } else if (compression == 2) {
        if (!inflate_data(data, size, 15, decoded, error)) return false;
    } else if (compression == 3) {
        if (size > kMaxNbtBytes) {
            set_error(error, "Uncompressed NBT exceeds safety limit");
            return false;
        }
        decoded.assign(data, data + size);
    } else {
        set_error(error, "Unsupported Anvil chunk compression type: " +
                         std::to_string(compression));
        return false;
    }
    return parse_nbt(decoded, root, error);
}

std::string join_path(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    const char last = a.back();
    return a + ((last == '/' || last == '\\') ? "" : "/") + b;
}

bool load_level_dat(const std::string& path, NbtTag& root, std::string* error) {
    std::vector<std::uint8_t> compressed;
    if (!read_file(path, compressed, error)) return false;
    std::vector<std::uint8_t> decoded;
    if (!inflate_data(compressed.data(), compressed.size(), 15 + 16, decoded, error)) return false;
    return parse_nbt(decoded, root, error);
}

bool copy_byte_array(const NbtTag* tag, std::uint8_t* destination,
                     std::size_t expected) {
    if (!tag || tag->type != 7 || tag->bytes.size() != expected) return false;
    std::copy(tag->bytes.begin(), tag->bytes.end(), destination);
    return true;
}

} // namespace

const NbtTag* NbtTag::find(const std::string& child_name) const noexcept {
    for (const NbtTag& child : children)
        if (child.name == child_name) return &child;
    return nullptr;
}

const NbtTag* NbtTag::at(std::size_t index) const noexcept {
    return index < children.size() ? &children[index] : nullptr;
}

std::uint8_t LegacyChunkSection::block_id(std::uint8_t x, std::uint8_t y_local,
                                          std::uint8_t z) const noexcept {
    if (x > 15 || y_local > 15 || z > 15) return 0;
    const std::size_t index = (static_cast<std::size_t>(y_local) * 16 + z) * 16 + x;
    return blocks[index];
}

std::uint8_t LegacyChunkSection::block_data(std::uint8_t x, std::uint8_t y_local,
                                            std::uint8_t z) const noexcept {
    if (x > 15 || y_local > 15 || z > 15) return 0;
    const std::size_t index = (static_cast<std::size_t>(y_local) * 16 + z) * 16 + x;
    const std::uint8_t packed = metadata[index / 2];
    return (index & 1u) ? static_cast<std::uint8_t>(packed >> 4)
                        : static_cast<std::uint8_t>(packed & 0x0fu);
}

bool parse_nbt(const std::vector<std::uint8_t>& bytes, NbtTag& root,
               std::string* error) {
    if (bytes.empty() || bytes.size() > kMaxNbtBytes) {
        set_error(error, "NBT document is empty or exceeds safety limit");
        return false;
    }
    NbtParser parser(bytes);
    return parser.parse(root, error);
}

std::int32_t floor_div_32(std::int32_t value) noexcept {
    std::int32_t quotient = value / 32;
    if (value < 0 && value % 32 != 0) --quotient;
    return quotient;
}

std::uint8_t floor_mod_32(std::int32_t value) noexcept {
    const std::int32_t remainder = value % 32;
    return static_cast<std::uint8_t>(remainder < 0 ? remainder + 32 : remainder);
}

bool WorldSave::open(const std::string& save_directory, std::string* error) {
    NbtTag root;
    std::string primary_error;
    const std::string primary = join_path(save_directory, "level.dat");
    if (!load_level_dat(primary, root, &primary_error)) {
        std::string backup_error;
        if (!load_level_dat(join_path(save_directory, "level.dat_old"), root, &backup_error)) {
            set_error(error, "Cannot load level.dat (" + primary_error +
                             "); backup also failed (" + backup_error + ")");
            return false;
        }
    }
    const NbtTag* data = root.find("Data");
    if (!data || data->type != 10) {
        set_error(error, "level.dat has no Data compound");
        return false;
    }
    WorldMetadata metadata;
    const NbtTag* name = data->find("LevelName");
    if (name && name->type == 8) metadata.level_name = name->string_value;
    metadata.spawn_x = as_i32(data->find("SpawnX"), 0);
    metadata.spawn_y = as_i32(data->find("SpawnY"), 64);
    metadata.spawn_z = as_i32(data->find("SpawnZ"), 0);
    metadata.game_type = as_i32(data->find("GameType"), 0);
    metadata.version = as_i32(data->find("version"), 0);
    metadata.seed = as_i64(data->find("RandomSeed"), 0);
    metadata.world_time = as_i64(data->find("Time"), 0);
    metadata.last_played = as_i64(data->find("LastPlayed"), 0);
    directory_ = save_directory;
    metadata_ = std::move(metadata);
    return true;
}

bool WorldSave::read_chunk(std::int32_t chunk_x, std::int32_t chunk_z,
                           ChunkData& output, std::string* error) const {
    if (directory_.empty()) {
        set_error(error, "WorldSave is not open");
        return false;
    }
    const std::int32_t region_x = floor_div_32(chunk_x);
    const std::int32_t region_z = floor_div_32(chunk_z);
    const std::uint8_t local_x = floor_mod_32(chunk_x);
    const std::uint8_t local_z = floor_mod_32(chunk_z);
    const std::string filename = "r." + std::to_string(region_x) + "." +
                                 std::to_string(region_z) + ".mca";
    const std::string path = join_path(join_path(directory_, "region"), filename);
    std::vector<std::uint8_t> region;
    if (!read_file(path, region, error)) return false;
    if (region.size() < kRegionHeaderBytes || region.size() % kSectorBytes != 0) {
        set_error(error, "Invalid Anvil region size/header: " + path);
        return false;
    }
    const std::size_t slot = static_cast<std::size_t>(local_x) +
                             static_cast<std::size_t>(local_z) * 32;
    const std::uint32_t location = read_u32(region.data() + slot * 4);
    const std::uint32_t sector_offset = location >> 8;
    const std::uint32_t sector_count = location & 0xffu;
    if (sector_offset == 0 || sector_count == 0) {
        set_error(error, "Chunk is not present in region file");
        return false;
    }
    const std::uint64_t byte_offset = static_cast<std::uint64_t>(sector_offset) * kSectorBytes;
    const std::uint64_t allocation_size = static_cast<std::uint64_t>(sector_count) * kSectorBytes;
    if (sector_offset < 2 || byte_offset + allocation_size > region.size() ||
        byte_offset + 5 > region.size()) {
        set_error(error, "Chunk sector range is outside region file");
        return false;
    }
    const std::uint8_t* chunk = region.data() + static_cast<std::size_t>(byte_offset);
    const std::uint32_t length = read_u32(chunk);
    if (length < 1 || static_cast<std::uint64_t>(length) > allocation_size - 4 ||
        byte_offset + 4u + length > region.size()) {
        set_error(error, "Invalid chunk record length in region file");
        return false;
    }
    const std::uint8_t compression = chunk[4];
    NbtTag root;
    if (!decode_nbt_payload(chunk + 5, length - 1, compression, root, error)) return false;
    const NbtTag* level = root.find("Level");
    if (!level || level->type != 10) {
        set_error(error, "Chunk NBT has no legacy Level compound");
        return false;
    }
    ChunkData parsed;
    parsed.x = as_i32(level->find("xPos"), chunk_x);
    parsed.z = as_i32(level->find("zPos"), chunk_z);
    const NbtTag* populated = level->find("TerrainPopulated");
    parsed.terrain_populated = populated && populated->type == 1 && populated->integer != 0;
    const NbtTag* height = level->find("HeightMap");
    if (height && height->type == 11 && height->ints.size() >= 256) {
        for (std::size_t i = 0; i < parsed.height_map.size(); ++i)
            parsed.height_map[i] = static_cast<std::uint8_t>(std::clamp(height->ints[i], 0, 255));
    }
    const NbtTag* sections = level->find("Sections");
    if (sections && sections->type == 9 && sections->list_element_type == 10) {
        parsed.sections.reserve(sections->children.size());
        for (const NbtTag& tag : sections->children) {
            if (tag.type != 10) continue;
            const NbtTag* y = tag.find("Y");
            const NbtTag* blocks = tag.find("Blocks");
            const NbtTag* data = tag.find("Data");
            if (!y || y->type != 1 || !blocks || blocks->type != 7 ||
                blocks->bytes.size() != 4096 || !data || data->type != 7 ||
                data->bytes.size() != 2048) {
                set_error(error, "Chunk contains an invalid legacy section layout");
                return false;
            }
            LegacyChunkSection section;
            section.y = static_cast<std::int8_t>(y->integer);
            std::copy(blocks->bytes.begin(), blocks->bytes.end(), section.blocks.begin());
            std::copy(data->bytes.begin(), data->bytes.end(), section.metadata.begin());
            section.has_block_light = copy_byte_array(tag.find("BlockLight"),
                                                       section.block_light.data(), 2048);
            section.has_sky_light = copy_byte_array(tag.find("SkyLight"),
                                                     section.sky_light.data(), 2048);
            parsed.sections.push_back(std::move(section));
        }
    }
    parsed.nbt = std::move(root);
    output = std::move(parsed);
    return true;
}

} // namespace opti::world
