#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/../../.." && pwd)"
OUT="${TMPDIR:-/tmp}/opticraft-world-save-reader-test"
c++ -std=c++17 -Wall -Wextra -Werror -pedantic \
  -I"$ROOT/runtime/world/include" \
  "$ROOT/runtime/world/src/world_save_reader.cpp" \
  "$ROOT/runtime/world/tests/world_save_reader_test.cpp" \
  -lz -o "$OUT"
"$OUT" "$@"
echo "PASS Java Edition 1.2.x level.dat + Anvil .mca world reader"
