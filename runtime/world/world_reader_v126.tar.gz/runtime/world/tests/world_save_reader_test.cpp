#include "world_save_reader.hpp"

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <zlib.h>

namespace fs = std::filesystem;
using namespace opti::world;

static void put_u8(std::vector<std::uint8_t>& out, std::uint8_t v) { out.push_back(v); }
static void put_u16(std::vector<std::uint8_t>& out, std::uint16_t v) {
    out.push_back(static_cast<std::uint8_t>(v >> 8));
    out.push_back(static_cast<std::uint8_t>(v));
}
static void put_u32(std::vector<std::uint8_t>& out, std::uint32_t v) {
    out.push_back(static_cast<std::uint8_t>(v >> 24));
    out.push_back(static_cast<std::uint8_t>(v >> 16));
    out.push_back(static_cast<std::uint8_t>(v >> 8));
    out.push_back(static_cast<std::uint8_t>(v));
}
static void put_u64(std::vector<std::uint8_t>& out, std::uint64_t v) {
    put_u32(out, static_cast<std::uint32_t>(v >> 32));
    put_u32(out, static_cast<std::uint32_t>(v));
}
static void put_string(std::vector<std::uint8_t>& out, const std::string& s) {
    put_u16(out, static_cast<std::uint16_t>(s.size()));
    out.insert(out.end(), s.begin(), s.end());
}
static void named_header(std::vector<std::uint8_t>& out, std::uint8_t type,
                         const std::string& name) {
    put_u8(out, type);
    put_string(out, name);
}
static void tag_byte(std::vector<std::uint8_t>& out, const std::string& name,
                     std::uint8_t value) {
    named_header(out, 1, name); put_u8(out, value);
}
static void tag_int(std::vector<std::uint8_t>& out, const std::string& name,
                    std::int32_t value) {
    named_header(out, 3, name); put_u32(out, static_cast<std::uint32_t>(value));
}
static void tag_long(std::vector<std::uint8_t>& out, const std::string& name,
                     std::int64_t value) {
    named_header(out, 4, name); put_u64(out, static_cast<std::uint64_t>(value));
}
static void tag_string(std::vector<std::uint8_t>& out, const std::string& name,
                       const std::string& value) {
    named_header(out, 8, name); put_string(out, value);
}
static void tag_byte_array(std::vector<std::uint8_t>& out, const std::string& name,
                           const std::vector<std::uint8_t>& bytes) {
    named_header(out, 7, name); put_u32(out, static_cast<std::uint32_t>(bytes.size()));
    out.insert(out.end(), bytes.begin(), bytes.end());
}
static void tag_int_array(std::vector<std::uint8_t>& out, const std::string& name,
                          const std::vector<std::int32_t>& values) {
    named_header(out, 11, name); put_u32(out, static_cast<std::uint32_t>(values.size()));
    for (std::int32_t v : values) put_u32(out, static_cast<std::uint32_t>(v));
}

static std::vector<std::uint8_t> gzip_compress(const std::vector<std::uint8_t>& input) {
    z_stream stream{};
    assert(deflateInit2(&stream, Z_BEST_COMPRESSION, Z_DEFLATED, 15 + 16, 8,
                        Z_DEFAULT_STRATEGY) == Z_OK);
    std::vector<std::uint8_t> output(1024 + input.size());
    stream.next_in = const_cast<Bytef*>(input.data());
    stream.avail_in = static_cast<uInt>(input.size());
    stream.next_out = output.data();
    stream.avail_out = static_cast<uInt>(output.size());
    assert(deflate(&stream, Z_FINISH) == Z_STREAM_END);
    output.resize(stream.total_out);
    deflateEnd(&stream);
    return output;
}

static std::vector<std::uint8_t> zlib_compress(const std::vector<std::uint8_t>& input) {
    uLongf output_size = compressBound(static_cast<uLong>(input.size()));
    std::vector<std::uint8_t> output(output_size);
    assert(compress2(output.data(), &output_size, input.data(),
                     static_cast<uLong>(input.size()), Z_BEST_COMPRESSION) == Z_OK);
    output.resize(output_size);
    return output;
}

static std::vector<std::uint8_t> make_level_nbt() {
    std::vector<std::uint8_t> out;
    put_u8(out, 10); put_string(out, "");
    named_header(out, 10, "Data");
    tag_string(out, "LevelName", "World Import Test");
    tag_int(out, "SpawnX", -17);
    tag_int(out, "SpawnY", 72);
    tag_int(out, "SpawnZ", 34);
    tag_int(out, "GameType", 0);
    tag_int(out, "version", 19133);
    tag_long(out, "RandomSeed", 123456789);
    tag_long(out, "Time", 6000);
    tag_long(out, "LastPlayed", 1700000000);
    put_u8(out, 0); // Data compound end
    put_u8(out, 0); // root compound end
    return out;
}

static std::vector<std::uint8_t> make_chunk_nbt() {
    std::vector<std::uint8_t> out;
    put_u8(out, 10); put_string(out, "");
    named_header(out, 10, "Level");
    tag_int(out, "xPos", 0);
    tag_int(out, "zPos", 0);
    tag_byte(out, "TerrainPopulated", 1);
    std::vector<std::int32_t> height(256, 64);
    tag_int_array(out, "HeightMap", height);

    named_header(out, 9, "Sections");
    put_u8(out, 10); // list element is Compound
    put_u32(out, 1);
    tag_byte(out, "Y", 0);
    tag_byte_array(out, "Blocks", std::vector<std::uint8_t>(4096, 42));
    std::vector<std::uint8_t> metadata(2048, 0x21);
    tag_byte_array(out, "Data", metadata);
    tag_byte_array(out, "BlockLight", std::vector<std::uint8_t>(2048, 0x77));
    tag_byte_array(out, "SkyLight", std::vector<std::uint8_t>(2048, 0xff));
    put_u8(out, 0); // section compound end
    put_u8(out, 0); // Level compound end
    put_u8(out, 0); // root compound end
    return out;
}

static void write_u32_at(std::vector<std::uint8_t>& out, std::size_t offset,
                         std::uint32_t value) {
    out[offset] = static_cast<std::uint8_t>(value >> 24);
    out[offset + 1] = static_cast<std::uint8_t>(value >> 16);
    out[offset + 2] = static_cast<std::uint8_t>(value >> 8);
    out[offset + 3] = static_cast<std::uint8_t>(value);
}

static fs::path make_fixture_world() {
    const fs::path root = fs::temp_directory_path() / "opticraft-v126-world-fixture";
    fs::remove_all(root);
    fs::create_directories(root / "region");
    const auto level = gzip_compress(make_level_nbt());
    {
        std::ofstream file(root / "level.dat", std::ios::binary);
        file.write(reinterpret_cast<const char*>(level.data()),
                   static_cast<std::streamsize>(level.size()));
    }
    const auto chunk = zlib_compress(make_chunk_nbt());
    const std::size_t record_size = chunk.size() + 5;
    const std::size_t sectors = (record_size + 4095) / 4096;
    std::vector<std::uint8_t> region((2 + sectors) * 4096, 0);
    write_u32_at(region, 0, (2u << 8) | static_cast<std::uint32_t>(sectors));
    const std::size_t offset = 2 * 4096;
    write_u32_at(region, offset, static_cast<std::uint32_t>(chunk.size() + 1));
    region[offset + 4] = 2; // zlib
    std::copy(chunk.begin(), chunk.end(), region.begin() + static_cast<std::ptrdiff_t>(offset + 5));
    {
        std::ofstream file(root / "region" / "r.0.0.mca", std::ios::binary);
        file.write(reinterpret_cast<const char*>(region.data()),
                   static_cast<std::streamsize>(region.size()));
    }
    return root;
}

static void test_fixture_world() {
    const fs::path root = make_fixture_world();
    WorldSave world;
    std::string error;
    assert(world.open(root.string(), &error) && error.empty());
    assert(world.metadata().level_name == "World Import Test");
    assert(world.metadata().spawn_x == -17 && world.metadata().spawn_y == 72);
    assert(world.metadata().version == 19133);
    assert(world.metadata().seed == 123456789);

    ChunkData chunk;
    assert(world.read_chunk(0, 0, chunk, &error) && error.empty());
    assert(chunk.x == 0 && chunk.z == 0 && chunk.terrain_populated);
    assert(chunk.sections.size() == 1 && chunk.sections[0].y == 0);
    assert(chunk.sections[0].block_id(0, 0, 0) == 42);
    assert(chunk.sections[0].block_data(0, 0, 0) == 1);
    assert(chunk.sections[0].block_data(1, 0, 0) == 2);
    assert(chunk.sections[0].has_block_light && chunk.sections[0].has_sky_light);
    assert(chunk.height_map[0] == 64);
    assert(chunk.nbt.find("Level") != nullptr);

    assert(floor_div_32(-1) == -1 && floor_mod_32(-1) == 31);
    assert(floor_div_32(-32) == -1 && floor_mod_32(-32) == 0);
    assert(floor_div_32(-33) == -2 && floor_mod_32(-33) == 31);
    fs::remove_all(root);
    std::cout << "PASS generated Java Anvil world fixture\n";
}

static void test_original_world(const fs::path& root) {
    WorldSave world;
    std::string error;
    assert(world.open(root.string(), &error));
    assert(!world.metadata().level_name.empty());
    bool found_chunk = false;
    for (std::int32_t z = 0; z < 32 && !found_chunk; ++z) {
        for (std::int32_t x = 0; x < 32 && !found_chunk; ++x) {
            ChunkData chunk;
            if (world.read_chunk(-32 + x, z, chunk, nullptr)) {
                assert(chunk.x == -32 + x);
                assert(chunk.z == z);
                assert(!chunk.sections.empty());
                found_chunk = true;
            }
        }
    }
    assert(found_chunk && "uploaded OptiCraft sample world should contain a readable chunk in r.-1.0.mca");
    std::cout << "PASS original OptiCraft bundled save: " << world.metadata().level_name
              << "; parsed a chunk from region r.-1.0.mca\n";
}

int main(int argc, char** argv) {
    test_fixture_world();
    if (argc > 1) test_original_world(argv[1]);
    return 0;
}
