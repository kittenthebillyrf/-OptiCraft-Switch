#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace opti::world {

// NBT tag values follow the Java Edition binary format (TAG_End .. TAG_Long_Array).
struct NbtTag {
    std::uint8_t type = 0;
    std::string name;
    std::int64_t integer = 0;
    double decimal = 0.0;
    std::string string_value;
    std::vector<std::uint8_t> bytes;
    std::vector<std::int32_t> ints;
    std::vector<std::int64_t> longs;
    std::uint8_t list_element_type = 0;
    std::vector<NbtTag> children;

    const NbtTag* find(const std::string& child_name) const noexcept;
    const NbtTag* at(std::size_t index) const noexcept;
};

struct WorldMetadata {
    std::string level_name;
    std::int32_t spawn_x = 0;
    std::int32_t spawn_y = 64;
    std::int32_t spawn_z = 0;
    std::int32_t game_type = 0;
    std::int32_t version = 0;
    std::int64_t seed = 0;
    std::int64_t world_time = 0;
    std::int64_t last_played = 0;
};

struct LegacyChunkSection {
    std::int8_t y = 0;
    std::array<std::uint8_t, 4096> blocks{};
    std::array<std::uint8_t, 2048> metadata{};
    std::array<std::uint8_t, 2048> block_light{};
    std::array<std::uint8_t, 2048> sky_light{};
    bool has_block_light = false;
    bool has_sky_light = false;

    std::uint8_t block_id(std::uint8_t x, std::uint8_t y_local,
                          std::uint8_t z) const noexcept;
    std::uint8_t block_data(std::uint8_t x, std::uint8_t y_local,
                            std::uint8_t z) const noexcept;
};

struct ChunkData {
    std::int32_t x = 0;
    std::int32_t z = 0;
    bool terrain_populated = false;
    std::array<std::uint8_t, 256> height_map{};
    std::vector<LegacyChunkSection> sections;
    // The complete NBT tree is retained so entities, tile entities, structures,
    // scheduled ticks and unknown future tags are not discarded by the reader.
    NbtTag nbt;
};

// Reads Java Edition level.dat and Anvil region files (.mca), including the
// 1.2.x legacy section layout. It is a format reader, not a block renderer.
class WorldSave {
public:
    bool open(const std::string& save_directory, std::string* error = nullptr);
    bool read_chunk(std::int32_t chunk_x, std::int32_t chunk_z,
                    ChunkData& output, std::string* error = nullptr) const;

    const WorldMetadata& metadata() const noexcept { return metadata_; }
    const std::string& directory() const noexcept { return directory_; }

private:
    std::string directory_;
    WorldMetadata metadata_;
};

// Parses a complete, uncompressed NBT document whose root tag is a Compound.
bool parse_nbt(const std::vector<std::uint8_t>& bytes, NbtTag& root,
               std::string* error = nullptr);

// Utility for region-coordinate math; correct for negative chunk coordinates.
std::int32_t floor_div_32(std::int32_t value) noexcept;
std::uint8_t floor_mod_32(std::int32_t value) noexcept;

} // namespace opti::world
